#!/bin/bash
#info

clear
./screenfetch
